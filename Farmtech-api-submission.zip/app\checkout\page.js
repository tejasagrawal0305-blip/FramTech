'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { apiRequest } from '../lib/api-client';
import '../styles/checkout.css';

export default function Checkout() {
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    address: '',
    city: '',
    state: '',
    zipcode: '',
    startDate: '',
    endDate: '',
    securityDeposit: true,
    insuranceOpt: false,
    cardName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: ''
  });
  const [orderItems, setOrderItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    apiRequest('/equipment?availability=available')
      .then(({ data }) => {
        const equipment = data[0];
        if (equipment) setOrderItems([{ equipmentId: equipment.id, name: equipment.name, days: 1, pricePerDay: equipment.pricePerDay, total: equipment.pricePerDay }]);
      })
      .catch((requestError) => setError(requestError.message))
      .finally(() => setLoading(false));
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    const item = orderItems[0];
    if (!item) return setError('No available equipment is currently loaded.');
    setSubmitting(true);
    apiRequest('/rentals', { method: 'POST', body: JSON.stringify({ equipmentId: item.equipmentId, startDate: formData.startDate, endDate: formData.endDate }) })
      .then((rental) => setSuccess(`Booking ${rental.id} created successfully. Your rental is pending confirmation.`))
      .catch((requestError) => setError(requestError.message))
      .finally(() => setSubmitting(false));
  };

  const securityDeposit = 2000;
  const platformFee = 299;
  const subtotal = orderItems.reduce((sum, item) => sum + item.total, 0);
  const total = subtotal + securityDeposit + platformFee;

  return (
    <main>
      <section className="section section-white">
        <div className="container">
          <h1 style={{ marginBottom: '2rem', textAlign: 'center' }}>Complete Your Booking</h1>

          <div className="checkout-container">
            {/* Checkout Form */}
            <form onSubmit={handleSubmit} className="checkout-form">
              {loading && <p>Loading available equipment...</p>}
              {error && <div className="error-message" role="alert">{error}</div>}
              {success && <div className="success-message" role="status">{success}</div>}
              {/* Personal Information */}
              <div className="checkout-section">
                <h3>Personal Information</h3>
                
                <div className="form-row">
                  <div className="form-group">
                    <label>First Name *</label>
                    <input
                      type="text"
                      name="firstName"
                      value={formData.firstName}
                      onChange={handleChange}
                      required
                      placeholder="John"
                    />
                  </div>
                  <div className="form-group">
                    <label>Last Name *</label>
                    <input
                      type="text"
                      name="lastName"
                      value={formData.lastName}
                      onChange={handleChange}
                      required
                      placeholder="Doe"
                    />
                  </div>
                </div>

                <div className="form-row full">
                  <div className="form-group">
                    <label>Email *</label>
                    <input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      placeholder="john@example.com"
                    />
                  </div>
                </div>

                <div className="form-row full">
                  <div className="form-group">
                    <label>Phone Number *</label>
                    <input
                      type="tel"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      required
                      placeholder="+91 98765 43210"
                    />
                  </div>
                </div>
              </div>

              {/* Delivery Address */}
              <div className="checkout-section">
                <h3>Delivery Address</h3>
                
                <div className="form-row full">
                  <div className="form-group">
                    <label>Address *</label>
                    <input
                      type="text"
                      name="address"
                      value={formData.address}
                      onChange={handleChange}
                      required
                      placeholder="123 Farm Road"
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>City *</label>
                    <input
                      type="text"
                      name="city"
                      value={formData.city}
                      onChange={handleChange}
                      required
                      placeholder="Ludhiana"
                    />
                  </div>
                  <div className="form-group">
                    <label>State *</label>
                    <input
                      type="text"
                      name="state"
                      value={formData.state}
                      onChange={handleChange}
                      required
                      placeholder="Punjab"
                    />
                  </div>
                </div>

                <div className="form-row full">
                  <div className="form-group">
                    <label>Zip Code *</label>
                    <input
                      type="text"
                      name="zipcode"
                      value={formData.zipcode}
                      onChange={handleChange}
                      required
                      placeholder="141001"
                    />
                  </div>
                </div>
              </div>

              {/* Rental Dates */}
              <div className="checkout-section">
                <h3>Rental Dates</h3>
                
                <div className="form-row">
                  <div className="form-group">
                    <label>Start Date *</label>
                    <input
                      type="date"
                      name="startDate"
                      value={formData.startDate}
                      onChange={handleChange}
                      required
                    />
                  </div>
                  <div className="form-group">
                    <label>End Date *</label>
                    <input
                      type="date"
                      name="endDate"
                      value={formData.endDate}
                      onChange={handleChange}
                      required
                    />
                  </div>
                </div>
              </div>

              {/* Options */}
              <div className="checkout-section">
                <h3>Rental Options</h3>
                
                <div className="checkbox-group">
                  <input
                    type="checkbox"
                    name="securityDeposit"
                    checked={formData.securityDeposit}
                    onChange={handleChange}
                    id="security"
                  />
                  <label htmlFor="security">Secure deposit (₹{securityDeposit}) - Recommended</label>
                </div>

                <div className="checkbox-group">
                  <input
                    type="checkbox"
                    name="insuranceOpt"
                    checked={formData.insuranceOpt}
                    onChange={handleChange}
                    id="insurance"
                  />
                  <label htmlFor="insurance">Equipment Protection Insurance (+₹500)</label>
                </div>
              </div>

              {/* Payment Information */}
              <div className="checkout-section">
                <h3>Payment Information</h3>
                
                <div className="form-row full">
                  <div className="form-group">
                    <label>Cardholder Name *</label>
                    <input
                      type="text"
                      name="cardName"
                      value={formData.cardName}
                      onChange={handleChange}
                      required
                      placeholder="John Doe"
                    />
                  </div>
                </div>

                <div className="form-row full">
                  <div className="form-group">
                    <label>Card Number *</label>
                    <input
                      type="text"
                      name="cardNumber"
                      value={formData.cardNumber}
                      onChange={handleChange}
                      required
                      placeholder="1234 5678 9012 3456"
                      maxLength="19"
                    />
                  </div>
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Expiry Date *</label>
                    <input
                      type="text"
                      name="expiryDate"
                      value={formData.expiryDate}
                      onChange={handleChange}
                      required
                      placeholder="MM/YY"
                      maxLength="5"
                    />
                  </div>
                  <div className="form-group">
                    <label>CVV *</label>
                    <input
                      type="text"
                      name="cvv"
                      value={formData.cvv}
                      onChange={handleChange}
                      required
                      placeholder="123"
                      maxLength="3"
                    />
                  </div>
                </div>

                <div className="security-info">
                  🔒 Your payment is secure and encrypted
                </div>
              </div>

              <button type="submit" className="btn-success" disabled={submitting || loading} style={{ width: '100%', padding: '1rem', fontSize: '1.1rem', marginTop: '2rem' }}>
                {submitting ? 'Creating booking...' : 'Complete Payment & Book'}
              </button>

              <p style={{ textAlign: 'center', marginTop: '1rem', color: '#666', fontSize: '0.9rem' }}>
                By clicking &quot;Complete Payment&quot;, you agree to our <Link href="#" style={{ color: '#27ae60' }}>Terms & Conditions</Link>
              </p>
            </form>

            {/* Order Summary */}
            <div className="order-summary">
              <h3>Order Summary</h3>

              {orderItems.map((item, idx) => (
                <div key={idx} className="summary-item">
                  <div>
                    <div className="item-name">{item.name}</div>
                    <div className="item-details">{item.days} days × ₹{item.pricePerDay}/day</div>
                  </div>
                  <div className="item-price">₹{item.total.toLocaleString()}</div>
                </div>
              ))}

              <div className="summary-divider"></div>

              <div className="summary-row">
                <span>Subtotal:</span>
                <span>₹{subtotal.toLocaleString()}</span>
              </div>

              {formData.securityDeposit && (
                <div className="summary-row">
                  <span>Security Deposit:</span>
                  <span>₹{securityDeposit.toLocaleString()}</span>
                </div>
              )}

              {formData.insuranceOpt && (
                <div className="summary-row">
                  <span>Insurance:</span>
                  <span>₹500</span>
                </div>
              )}

              <div className="summary-row">
                <span>Platform Fee:</span>
                <span>₹{platformFee}</span>
              </div>

              <div className="summary-divider"></div>

              <div className="summary-row total">
                <span>Total Amount:</span>
                <span className="amount">₹{total.toLocaleString()}</span>
              </div>

              <div style={{ marginTop: '1.5rem', padding: '1rem', backgroundColor: '#f5f5f5', borderRadius: '5px', fontSize: '0.9rem', color: '#666' }}>
                <strong>Estimated Delivery:</strong> Within 24 hours of confirmation
              </div>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
