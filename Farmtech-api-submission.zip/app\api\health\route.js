import { json } from '../../../lib/http.js';

export const runtime = 'nodejs';

export function GET() {
  return json({ status: 'ok', service: 'farmtech-api', timestamp: new Date().toISOString() });
}