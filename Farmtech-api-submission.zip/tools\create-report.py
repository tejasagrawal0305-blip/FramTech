from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor
from docx.enum.section import WD_SECTION

report = Document()
styles = report.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal'].font.size = Pt(10.5)
styles['Normal'].font.color.rgb = RGBColor(33, 53, 43)

section = report.sections[0]
section.top_margin = Inches(0.7)
section.bottom_margin = Inches(0.7)
section.left_margin = Inches(0.8)
section.right_margin = Inches(0.8)

paragraph = report.add_paragraph()
paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = paragraph.add_run('FARMTECH')
run.bold = True
run.font.size = Pt(30)
run.font.color.rgb = RGBColor(19, 92, 61)
paragraph = report.add_paragraph()
paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = paragraph.add_run('Full-Stack Frontend and Backend Integration Report')
run.bold = True
run.font.size = Pt(16)
run.font.color.rgb = RGBColor(39, 174, 96)
paragraph = report.add_paragraph()
paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
paragraph.add_run('September 2026').italic = True

report.add_heading('Contents', level=1)
for item in ['Executive Summary', 'Project Objectives', 'System Architecture', 'Frontend Integration', 'Backend and Data Design', 'API Coverage', 'Security and Validation', 'Testing and Results', 'Challenges and Solutions', 'Limitations and Future Improvements', 'Setup and Submission Contents']:
    report.add_paragraph(item, style='List Number')

report.add_heading('Executive Summary', level=1)
report.add_paragraph(
    'This report documents the completed integration of the FarmTech agricultural equipment rental frontend with its RESTful backend APIs. '
    'FarmTech is implemented as one cohesive Next.js full-stack application: React client pages provide the user experience, while Next.js '
    'Route Handlers provide server-side API endpoints and a persistent local document store. The integrated system supports account creation, '
    'login, equipment search, equipment management, rental booking, rental listing, and rental status changes. The browser no longer depends '
    'on mock alerts for the core workflows. Instead, it performs asynchronous requests, persists the authenticated session token, renders live '
    'records, and displays useful loading, success, and error states. The backend remains responsible for validation, password hashing, ownership '
    'checks, availability checks, date conflict detection, and calculated booking totals. This separation keeps business rules on the server while '
    'allowing the interface to remain responsive and straightforward to maintain.'
)

report.add_heading('Project Objectives', level=1)
report.add_paragraph('The integration task was completed against the following objectives:')
for item in [
    'Connect the existing frontend screens to real backend endpoints using asynchronous HTTP requests.',
    'Create a consistent client-side request layer for JSON parsing, authentication headers, and error handling.',
    'Replace hard-coded equipment, mock login, mock registration, and mock checkout behavior with live API interactions.',
    'Preserve the API as the source of truth for users, equipment, rental ownership, availability, and booking conflicts.',
    'Document local setup, integration decisions, testing commands, and known limitations for another developer or evaluator.',
]:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('Technology Stack', level=1)
for item in [
    'Next.js 16 with App Router and Route Handlers',
    'React client components with asynchronous fetch and state management',
    'Node.js built-in crypto for scrypt password hashing and random sessions',
    'File-backed JSON document database with atomic replacement writes',
    'Node test runner and ESLint for automated verification',
]:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('System Architecture', level=1)
report.add_paragraph('The application uses a same-origin architecture. The browser runs React client components and sends relative requests to /api. Next.js resolves those requests to Route Handlers in app/api. The handlers call shared modules in lib for persistence, authentication, validation, and response formatting. This arrangement removes the need for CORS configuration during local development and keeps deployment simple because the frontend and backend share the same process.')
for item in [
    'Presentation layer: app/equipment, app/login, app/register, app/my-rentals, and app/checkout.',
    'Integration layer: app/lib/api-client.js adds JSON headers, bearer tokens, response parsing, and equipment field normalization.',
    'API layer: health, auth, equipment, and rentals Route Handlers expose public and protected HTTP operations.',
    'Domain layer: lib/auth.js, lib/validation.js, and rental checks enforce security and business rules.',
    'Persistence layer: lib/db.js initializes seed records and performs atomic JSON document reads and writes.',
]:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('Frontend Integration', level=1)
report.add_heading('Equipment browsing', level=2)
report.add_paragraph('The equipment page calls GET /api/equipment on mount. The response is mapped into the existing EquipmentCard contract, including conversion from pricePerDay to the legacy price display field and from lowercase availability values to the title-cased labels used by the stylesheet. Search, category, location, and price-range filters run against the loaded records. A loading message is shown while the request is pending, and a demo fallback is shown if the API cannot be reached.')
report.add_heading('Authentication', level=2)
report.add_paragraph('Registration and login send JSON credentials to the corresponding authentication endpoints. A successful response contains a user object and opaque session token. The shared client stores the token in localStorage, automatically attaches it to protected requests, and redirects the user to My Rentals. Invalid credentials, duplicate email addresses, and network failures are displayed as form errors. Submit buttons are disabled while requests are in progress.')
report.add_heading('Rentals and checkout', level=2)
report.add_paragraph('My Rentals requests GET /api/rentals and displays records belonging to the current user. API statuses are translated into the existing Active, Upcoming, and Previous tabs. Checkout first loads available equipment, then submits POST /api/rentals with equipmentId, startDate, and endDate. The server calculates days and total, rejects unavailable equipment and overlapping dates, and returns an error that the form displays without losing the rest of the page state.')

report.add_heading('Integration Flow', level=1)
report.add_paragraph('The browser sends relative requests to /api, so frontend and backend share one origin and do not require CORS configuration. The flow is:')
for item in [
    'User registers or logs in; the API returns a bearer token and the browser stores it locally.',
    'Equipment and checkout pages request live records from the API and render loading or error states.',
    'Protected rental and equipment requests automatically include the bearer token.',
    'The backend validates input, applies availability and ownership rules, persists changes, and returns JSON responses.',
]:
    report.add_paragraph(item, style='List Number')

report.add_heading('Backend and Data Design', level=1)
report.add_paragraph('The backend uses four document collections: users, sessions, equipment, and rentals. The JSON file is created on demand and seeded with six equipment records. Writes use a temporary file followed by rename, reducing the chance of leaving a partially written database. FARMTECH_DB_FILE can point to an isolated file for tests or a separate local environment.')
report.add_paragraph('A rental stores userId and equipmentId references plus an equipmentName snapshot, date range, calculated day count, calculated total, status, and creation timestamp. Before insertion, the API checks that the equipment exists, is available, has valid dates, and has no overlapping pending, confirmed, or active booking. Rental reads and mutations additionally require the authenticated user to own the record.')

report.add_heading('API Coverage', level=1)
api_table = report.add_table(rows=1, cols=4)
api_table.style = 'Table Grid'
for cell, text in zip(api_table.rows[0].cells, ['Area', 'Methods', 'Authentication', 'Purpose']):
    cell.text = text
for row in [
    ('Health', 'GET /health', 'Public', 'Service status and timestamp'),
    ('Auth', 'POST /auth/register, POST /auth/login', 'Public', 'Create accounts and sessions'),
    ('Equipment', 'GET, POST /equipment; GET, PATCH, DELETE /equipment/:id', 'Reads public; mutations protected', 'Search and equipment CRUD'),
    ('Rentals', 'GET, POST /rentals; GET, PATCH, DELETE /rentals/:id', 'Protected', 'Create and manage owned bookings'),
]:
    cells = api_table.add_row().cells
    for cell, text in zip(cells, row):
        cell.text = text
report.add_paragraph('The companion API_DOCUMENTATION.md and API_DOCUMENTATION.pdf provide complete parameter tables, example requests, expected response payloads, status codes, and data models.')

report.add_heading('Security and Validation', level=1)
for item in [
    'Passwords are never stored in plain text; scrypt derives a 64-byte hash using a random salt.',
    'Session tokens are cryptographically random values stored server-side with a seven-day expiration.',
    'Password hashes are removed from user response objects before serialization.',
    'Protected resources require Authorization: Bearer <token> and rental resources enforce user ownership.',
    'Registration validates required fields, email shape, password length, and duplicate email addresses.',
    'Rental dates use YYYY-MM-DD validation, reject reversed ranges, and detect overlapping active booking windows.',
    'Error responses use a consistent JSON envelope and do not expose stack traces or database internals.',
]:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('Testing and Results', level=1)
report.add_paragraph('The automated suite uses the Node.js test runner and an isolated temporary database file. Four integration tests passed: the health endpoint returns service status; registration and login issue tokens without exposing password hashes; equipment supports public reads and authenticated create/update/delete operations; and rentals enforce authentication, availability, calculated duration, and overlapping-date conflicts. The changed frontend integration files also pass ESLint, and npm run build completes successfully with all API routes listed as dynamic server routes.')
report.add_paragraph('The production build emits a warning about dynamic filesystem access because the local database path is intentionally configurable. This is expected for the selected development-friendly document store and is documented as a deployment consideration.')

report.add_heading('Challenges and Solutions', level=1)
for item in [
    'Data contract mismatch: the original UI used price and title-cased availability, while the API uses pricePerDay and lowercase values. Solution: a shared equipment normalizer and a card-level compatibility fallback.',
    'Mock interactions: login, registration, and checkout originally used alerts. Solution: asynchronous API calls with disabled controls, persistent tokens, success messages, and server error rendering.',
    'Authentication across pages: protected requests needed one consistent behavior. Solution: api-client.js reads one localStorage token and attaches the bearer header automatically.',
    'Backend-owned booking rules: client-side checks alone would be unsafe. Solution: the rental endpoint validates dates, availability, conflicts, and ownership on the server.',
    'Missing presentation fields in rental records: the API does not fabricate owner or location values. Solution: the rentals UI maps known fields and uses explicit fallback labels.',
]:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('Limitations and Future Improvements', level=1)
report.add_paragraph('The current implementation is appropriate for local assessment and demonstration, but production deployment would benefit from a managed database, database-level transactions for concurrent bookings, secure httpOnly cookies instead of localStorage tokens, rate limiting on authentication routes, role-based authorization for equipment mutations, payment-provider integration, server-side pagination, and structured application logging. The current checkout intentionally creates the rental booking but does not process real card details; payment fields remain a presentation placeholder and should never be sent to this API without a compliant payment provider.')

report.add_heading('Validation and Deliverables', level=1)
report.add_paragraph('Verified commands: npm test, npm run lint for the changed integration files, and npm run build. The project ZIP includes both source layers, API documentation, README, tests, screenshots report, PDF documentation, Word report, and a local demo walkthrough at demo-video.html.')

report.add_heading('Submission Notes', level=1)
report.add_paragraph('Start the project with npm install followed by npm run dev. Open http://localhost:3000 for the interface. The API reference is in API_DOCUMENTATION.md and the generated PDF version is API_DOCUMENTATION.pdf.')

report.save('FarmTech-Integration-Report.docx')
