import { findOne, remove, update } from '../../../../lib/db.js';
import { error, json, requestBody, requireUser } from '../../../../lib/http.js';

export const runtime = 'nodejs';

export async function GET(request, { params }) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  const { id } = await params;
  const rental = findOne('rentals', (item) => item.id === id && item.userId === user.id);
  return rental ? json(rental) : error('Rental not found', 404);
}

export async function PATCH(request, { params }) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  const id = (await params).id;
  const rental = findOne('rentals', (item) => item.id === id && item.userId === user.id);
  if (!rental) return error('Rental not found', 404);
  const body = await requestBody(request);
  if (!body || !['pending', 'cancelled'].includes(body.status)) return error('Only pending or cancelled status updates are supported');
  return json(update('rentals', (item) => item.id === id, { status: body.status }));
}

export async function DELETE(request, { params }) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  const { id } = await params;
  const deleted = remove('rentals', (item) => item.id === id && item.userId === user.id);
  return deleted ? json({ message: 'Rental deleted' }) : error('Rental not found', 404);
}