import fs from 'node:fs';
import { marked } from 'marked';

const markdown = fs.readFileSync('API_DOCUMENTATION.md', 'utf8');
const rendered = marked.parse(markdown);
const html = `<!doctype html>
<html><head><meta charset="utf-8"><title>FarmTech REST API Documentation</title>
<style>
@page { size: A4; margin: 16mm; }
* { box-sizing: border-box; }
body { color: #21352b; font-family: Arial, sans-serif; font-size: 10pt; line-height: 1.45; }
h1 { color: #135c3d; font-size: 28pt; border-bottom: 4px solid #27ae60; padding-bottom: 8px; }
h2 { color: #135c3d; font-size: 18pt; margin-top: 24px; border-bottom: 1px solid #cfe4d5; padding-bottom: 4px; }
h3 { color: #246849; font-size: 13pt; margin-top: 18px; }
h4 { color: #246849; font-size: 11pt; margin-bottom: 4px; }
table { border-collapse: collapse; width: 100%; margin: 10px 0 16px; page-break-inside: avoid; }
th { background: #e8f5eb; color: #135c3d; text-align: left; }
th, td { border: 1px solid #bcd8c4; padding: 6px 8px; vertical-align: top; }
code { background: #f0f5f1; color: #185b3d; padding: 1px 4px; border-radius: 3px; font-family: Consolas, monospace; }
pre { background: #f4f7f4; border-left: 4px solid #27ae60; padding: 10px; overflow-wrap: anywhere; white-space: pre-wrap; page-break-inside: avoid; }
pre code { background: transparent; padding: 0; }
li { margin: 3px 0; }
</style></head><body>${rendered}</body></html>`;
fs.writeFileSync('API_DOCUMENTATION.html', html);
