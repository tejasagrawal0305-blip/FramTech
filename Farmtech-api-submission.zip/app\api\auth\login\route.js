import { createSession, verifyPassword } from '../../../../lib/auth.js';
import { findOne } from '../../../../lib/db.js';
import { error, json, requestBody } from '../../../../lib/http.js';
import { publicUser } from '../../../../lib/validation.js';

export const runtime = 'nodejs';

export async function POST(request) {
  const body = await requestBody(request);
  if (!body || typeof body.email !== 'string' || typeof body.password !== 'string') return error('email and password are required');
  const user = findOne('users', (item) => item.email === body.email.trim().toLowerCase());
  if (!user || !verifyPassword(body.password, user.passwordHash)) return error('Invalid email or password', 401);
  return json({ user: publicUser(user), token: createSession(user.id) });
}