'use client';

import { useState } from 'react';
import Link from 'next/link';
import '../styles/rentals.css';

// Sample rental data
const activeRentals = [
  {
    id: 1,
    name: 'John Deere Tractor',
    type: 'Tractor',
    status: 'Active',
    image: '🚜',
    startDate: '2024-09-01',
    endDate: '2024-09-05',
    price: 1500,
    location: 'Ludhiana, Punjab',
    owner: 'Harjeet Singh'
  },
  {
    id: 2,
    name: 'Combine Harvester',
    type: 'Harvester',
    status: 'Active',
    image: '🌾',
    startDate: '2024-09-03',
    endDate: '2024-09-08',
    price: 2500,
    location: 'Chandigarh',
    owner: 'Priya Sharma'
  }
];

const upcomingRentals = [
  {
    id: 3,
    name: 'Seed Drill',
    type: 'Seeding Equipment',
    status: 'Upcoming',
    image: '⚙️',
    startDate: '2024-09-15',
    endDate: '2024-09-18',
    price: 800,
    location: 'Jaipur, Rajasthan',
    owner: 'Rajesh Kumar'
  }
];

const previousRentals = [
  {
    id: 4,
    name: 'Sprayer Equipment',
    type: 'Spraying',
    status: 'Completed',
    image: '💧',
    startDate: '2024-08-10',
    endDate: '2024-08-15',
    price: 600,
    location: 'Pune, Maharashtra',
    owner: 'Amit Patel'
  },
  {
    id: 5,
    name: 'Power Thresher',
    type: 'Threshing',
    status: 'Completed',
    image: '🔄',
    startDate: '2024-07-20',
    endDate: '2024-07-25',
    price: 1200,
    location: 'Delhi',
    owner: 'Suresh Singh'
  }
];

export default function MyRentals() {
  const [activeTab, setActiveTab] = useState('active');

  const RentalCard = ({ rental }) => (
    <div className="rental-card">
      <div className="rental-image">{rental.image}</div>
      <div className="rental-content">
        <h3 className="rental-title">{rental.name}</h3>
        <span className={`rental-status ${rental.status.toLowerCase()}`}>
          {rental.status}
        </span>

        <div className="rental-dates">
          <div className="date-row">
            <strong>Start:</strong>
            <span>{new Date(rental.startDate).toLocaleDateString()}</span>
          </div>
          <div className="date-row">
            <strong>End:</strong>
            <span>{new Date(rental.endDate).toLocaleDateString()}</span>
          </div>
        </div>

        <div className="rental-detail">
          <span className="rental-detail-label">Price:</span>
          <span className="rental-detail-value">₹{rental.price}/day</span>
        </div>

        <div className="rental-detail">
          <span className="rental-detail-label">Location:</span>
          <span>📍 {rental.location}</span>
        </div>

        <div className="rental-detail">
          <span className="rental-detail-label">Owner:</span>
          <span>👨‍🌾 {rental.owner}</span>
        </div>

        <div className="rental-actions">
          {rental.status === 'Active' && (
            <>
              <button className="btn-primary">View Details</button>
              <button className="btn-secondary">Extend Rental</button>
            </>
          )}
          {rental.status === 'Upcoming' && (
            <>
              <button className="btn-primary">View Details</button>
              <button className="btn-secondary">Cancel Booking</button>
            </>
          )}
          {rental.status === 'Completed' && (
            <>
              <button className="btn-primary">Rent Again</button>
              <button className="btn-secondary">Leave Review</button>
            </>
          )}
        </div>
      </div>
    </div>
  );

  return (
    <main>
      {/* Header */}
      <section className="rentals-header">
        <div className="container">
          <h1>My Rentals</h1>
          <p>Manage and track all your equipment rentals</p>
        </div>
      </section>

      {/* Tabs and Content */}
      <section className="section section-light">
        <div className="container">
          {/* Tabs */}
          <div className="tabs-container">
            <button 
              className={`tab-button ${activeTab === 'active' ? 'active' : ''}`}
              onClick={() => setActiveTab('active')}
            >
              Active Rentals ({activeRentals.length})
            </button>
            <button 
              className={`tab-button ${activeTab === 'upcoming' ? 'active' : ''}`}
              onClick={() => setActiveTab('upcoming')}
            >
              Upcoming Bookings ({upcomingRentals.length})
            </button>
            <button 
              className={`tab-button ${activeTab === 'previous' ? 'active' : ''}`}
              onClick={() => setActiveTab('previous')}
            >
              Previous Rentals ({previousRentals.length})
            </button>
          </div>

          {/* Active Rentals */}
          {activeTab === 'active' && (
            <>
              {activeRentals.length > 0 ? (
                <div className="rentals-grid">
                  {activeRentals.map(rental => (
                    <RentalCard key={rental.id} rental={rental} />
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <div className="empty-state-icon">📭</div>
                  <h2>No Active Rentals</h2>
                  <p>You don't have any active rentals at the moment.</p>
                  <Link href="/equipment">Browse Equipment</Link>
                </div>
              )}
            </>
          )}

          {/* Upcoming Rentals */}
          {activeTab === 'upcoming' && (
            <>
              {upcomingRentals.length > 0 ? (
                <div className="rentals-grid">
                  {upcomingRentals.map(rental => (
                    <RentalCard key={rental.id} rental={rental} />
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <div className="empty-state-icon">📅</div>
                  <h2>No Upcoming Bookings</h2>
                  <p>You don't have any upcoming bookings.</p>
                  <Link href="/equipment">Book Equipment</Link>
                </div>
              )}
            </>
          )}

          {/* Previous Rentals */}
          {activeTab === 'previous' && (
            <>
              {previousRentals.length > 0 ? (
                <div className="rentals-grid">
                  {previousRentals.map(rental => (
                    <RentalCard key={rental.id} rental={rental} />
                  ))}
                </div>
              ) : (
                <div className="empty-state">
                  <div className="empty-state-icon">🏁</div>
                  <h2>No Previous Rentals</h2>
                  <p>You don't have any completed rentals yet.</p>
                  <Link href="/equipment">Start Renting</Link>
                </div>
              )}
            </>
          )}
        </div>
      </section>

      {/* Help Section */}
      <section className="section section-white">
        <div className="container" style={{ maxWidth: '800px', margin: '0 auto' }}>
          <h2 style={{ textAlign: 'center', marginBottom: '2rem' }}>Need Help?</h2>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>📞</div>
              <h3>Contact Support</h3>
              <p style={{ marginBottom: '1rem' }}>Need to modify or cancel a rental?</p>
              <Link href="#support" className="btn-primary" style={{ display: 'inline-block', padding: '0.75rem 1.5rem' }}>
                Get Help
              </Link>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '1rem' }}>❓</div>
              <h3>FAQ</h3>
              <p style={{ marginBottom: '1rem' }}>Find answers to common questions</p>
              <Link href="#faq" className="btn-primary" style={{ display: 'inline-block', padding: '0.75rem 1.5rem' }}>
                View FAQ
              </Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
