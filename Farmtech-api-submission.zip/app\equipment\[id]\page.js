'use client';

import { useState } from 'react';
import Link from 'next/link';
import '../../styles/equipment.css';

export default function EquipmentDetail({ params }) {
  const { id } = params;
  const [rentalDays, setRentalDays] = useState(1);

  // Sample equipment detail data
  const equipment = {
    id: id,
    name: 'John Deere Tractor Model 5050D',
    type: 'Agricultural Tractor',
    price: 1500,
    rating: 4.8,
    reviews: 127,
    location: 'Ludhiana, Punjab',
    owner: 'Harjeet Singh',
    ownerRating: 4.9,
    availability: 'Available',
    description: 'Powerful and reliable tractor perfect for medium-sized farms. Recently serviced and in excellent condition.',
    features: [
      '75 HP Engine',
      '4-Wheel Drive',
      'Power Steering',
      'Hydraulic System',
      'Latest Model (2022)',
      'Low Mileage'
    ],
    images: ['🚜', '🚜', '🚜'],
    specifications: {
      power: '75 HP',
      transmission: 'Synchronized',
      tyres: 'Agricultural',
      fuel: 'Diesel',
      capacity: '55 liters'
    }
  };

  const totalPrice = equipment.price * rentalDays;

  return (
    <main>
      <section className="section section-white">
        <div className="container">
          <Link href="/equipment" style={{ marginBottom: '2rem', display: 'block', color: '#27ae60' }}>
            ← Back to Equipment
          </Link>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem' }}>
            {/* Image Gallery */}
            <div>
              <div style={{
                backgroundColor: '#f5f5f5',
                borderRadius: '8px',
                padding: '2rem',
                textAlign: 'center',
                fontSize: '5rem',
                marginBottom: '1rem'
              }}>
                {equipment.images[0]}
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '1rem' }}>
                {equipment.images.map((img, idx) => (
                  <div key={idx} style={{
                    backgroundColor: '#f5f5f5',
                    borderRadius: '5px',
                    padding: '1rem',
                    textAlign: 'center',
                    fontSize: '2rem',
                    cursor: 'pointer'
                  }}>
                    {img}
                  </div>
                ))}
              </div>
            </div>

            {/* Details and Booking */}
            <div>
              <h1>{equipment.name}</h1>
              <p style={{ color: '#95a5a6', marginBottom: '1rem' }}>{equipment.type}</p>

              {/* Rating */}
              <div style={{ marginBottom: '1.5rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '0.5rem' }}>
                  <span style={{ color: '#f39c12', fontSize: '1.2rem' }}>★★★★★</span>
                  <span style={{ color: '#666' }}>({equipment.reviews} reviews)</span>
                </div>
              </div>

              {/* Price */}
              <div style={{
                backgroundColor: '#f5f5f5',
                padding: '1.5rem',
                borderRadius: '8px',
                marginBottom: '2rem'
              }}>
                <div style={{ fontSize: '0.9rem', color: '#666', marginBottom: '0.5rem' }}>Rental Price</div>
                <div style={{ fontSize: '2rem', fontWeight: 'bold', color: '#27ae60' }}>₹{equipment.price}</div>
                <div style={{ fontSize: '0.9rem', color: '#666' }}>per day</div>
              </div>

              {/* Location & Owner */}
              <div style={{ marginBottom: '2rem', paddingBottom: '2rem', borderBottom: '1px solid #ecf0f1' }}>
                <div style={{ marginBottom: '1rem' }}>
                  <div style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>📍 Location</div>
                  <div>{equipment.location}</div>
                </div>
                <div>
                  <div style={{ fontWeight: 'bold', marginBottom: '0.5rem' }}>👨‍🌾 Owner</div>
                  <div>{equipment.owner}</div>
                  <div style={{ fontSize: '0.9rem', color: '#95a5a6' }}>Rating: {equipment.ownerRating} ⭐</div>
                </div>
              </div>

              {/* Availability */}
              <div style={{
                backgroundColor: '#d4edda',
                padding: '0.75rem',
                borderRadius: '5px',
                color: '#155724',
                marginBottom: '2rem',
                textAlign: 'center'
              }}>
                ✓ {equipment.availability}
              </div>

              {/* Rental Duration */}
              <div className="form-group">
                <label>Rental Duration (Days)</label>
                <div style={{ display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
                  <button 
                    onClick={() => setRentalDays(Math.max(1, rentalDays - 1))}
                    style={{ padding: '0.5rem 1rem', backgroundColor: '#ecf0f1', border: 'none', borderRadius: '5px' }}
                  >
                    −
                  </button>
                  <input 
                    type="number" 
                    value={rentalDays}
                    onChange={(e) => setRentalDays(Math.max(1, parseInt(e.target.value) || 1))}
                    style={{ width: '80px', textAlign: 'center', padding: '0.5rem', border: '1px solid #ddd', borderRadius: '5px' }}
                  />
                  <button 
                    onClick={() => setRentalDays(rentalDays + 1)}
                    style={{ padding: '0.5rem 1rem', backgroundColor: '#ecf0f1', border: 'none', borderRadius: '5px' }}
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Total Price */}
              <div style={{
                backgroundColor: '#fafafa',
                padding: '1rem',
                borderRadius: '5px',
                marginBottom: '2rem',
                borderLeft: '4px solid #27ae60'
              }}>
                <div style={{ fontSize: '0.9rem', color: '#666', marginBottom: '0.5rem' }}>Total Cost</div>
                <div style={{ fontSize: '1.75rem', fontWeight: 'bold', color: '#27ae60' }}>
                  ₹{totalPrice.toLocaleString()}
                </div>
              </div>

              {/* Rent Button */}
              <Link href="/checkout" className="btn-primary" style={{ width: '100%', display: 'block', textAlign: 'center', padding: '1rem' }}>
                RENT NOW
              </Link>
            </div>
          </div>

          {/* Features Section */}
          <div style={{ marginTop: '4rem', paddingTop: '3rem', borderTop: '2px solid #ecf0f1' }}>
            <h2 style={{ marginBottom: '2rem' }}>Features & Specifications</h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '3rem' }}>
              <div>
                <h3 style={{ color: '#2d5a3d', marginBottom: '1rem' }}>Features</h3>
                <ul style={{ listStyle: 'none' }}>
                  {equipment.features.map((feature, idx) => (
                    <li key={idx} style={{ padding: '0.5rem 0', borderBottom: '1px solid #ecf0f1' }}>
                      ✓ {feature}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 style={{ color: '#2d5a3d', marginBottom: '1rem' }}>Specifications</h3>
                <div style={{ backgroundColor: '#f5f5f5', padding: '1.5rem', borderRadius: '5px' }}>
                  {Object.entries(equipment.specifications).map(([key, value]) => (
                    <div key={key} style={{ display: 'flex', justifyContent: 'space-between', paddingBottom: '0.75rem', borderBottom: '1px solid #ecf0f1', marginBottom: '0.75rem' }}>
                      <span style={{ fontWeight: '600', textTransform: 'capitalize' }}>{key}</span>
                      <span>{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Description */}
          <div style={{ marginTop: '4rem', paddingTop: '3rem', borderTop: '2px solid #ecf0f1' }}>
            <h2 style={{ marginBottom: '1rem' }}>About This Equipment</h2>
            <p style={{ fontSize: '1.05rem', lineHeight: '1.8', color: '#555' }}>
              {equipment.description}
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}
