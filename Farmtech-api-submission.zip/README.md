# FarmTech

FarmTech is a Next.js agricultural equipment rental application with a REST API and a local file-backed JSON document database.

## Setup

```bash
npm install
npm run dev
```

Open `http://localhost:3000`. The API is available at `http://localhost:3000/api` and initializes `data/farmtech.json` with demo equipment on first request.

## Verification

```bash
npm test
npm run lint
npm run build
```

Use `FARMTECH_DB_FILE` to point the API at another database path, which is useful for isolated test or deployment environments.

## Backend documentation

See [API_DOCUMENTATION.md](API_DOCUMENTATION.md) for endpoint methods, parameters, authentication, validation rules, business rules, and response formats.
