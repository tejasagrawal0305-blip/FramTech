'use client';

import { useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { apiRequest, setToken } from '../lib/api-client';
import '../styles/auth.css';

export default function Login() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    rememberMe: false
  });

  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === 'checkbox' ? checked : value
    });
    setError('');
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (!formData.email || !formData.password) {
      setError('Please fill in all fields');
      return;
    }

    setLoading(true);
    apiRequest('/auth/login', { method: 'POST', body: JSON.stringify({ email: formData.email, password: formData.password }) })
      .then(({ token }) => { setToken(token); router.push('/my-rentals'); })
      .catch((requestError) => setError(requestError.message))
      .finally(() => setLoading(false));
  };

  return (
    <main>
      <section className="section section-light">
        <div className="auth-container">
          <div className="auth-card">
            <div className="auth-header">
              <h1>Welcome Back</h1>
              <p>Login to your FarmTech account</p>
            </div>

            {error && <div className="error-message">{error}</div>}

            <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="email">Email Address</label>
                <input
                  id="email"
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="your@email.com"
                  required
                />
              </div>

              <div className="form-group">
                <label htmlFor="password">Password</label>
                <div style={{ position: 'relative' }}>
                  <input
                    id="password"
                    type={showPassword ? 'text' : 'password'}
                    name="password"
                    value={formData.password}
                    onChange={handleChange}
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    style={{
                      position: 'absolute',
                      right: '10px',
                      top: '12px',
                      background: 'none',
                      border: 'none',
                      cursor: 'pointer',
                      color: '#666'
                    }}
                  >
                    {showPassword ? '👁️' : '👁️‍🗨️'}
                  </button>
                </div>
              </div>

              <div className="checkbox-group">
                <input
                  id="remember"
                  type="checkbox"
                  name="rememberMe"
                  checked={formData.rememberMe}
                  onChange={handleChange}
                />
                <label htmlFor="remember">Remember me</label>
              </div>

              <button type="submit" className="auth-button" disabled={loading}>
                {loading ? 'Signing in...' : 'Login to Account'}
              </button>
            </form>

            <div style={{ textAlign: 'right', margin: '1rem 0' }}>
              <Link href="#forgot" style={{ color: '#27ae60', fontSize: '0.9rem' }}>
                Forgot Password?
              </Link>
            </div>

            <div className="auth-divider">
              <span>OR</span>
            </div>

            <button className="auth-button" style={{ backgroundColor: '#3b5998' }}>
              Continue with Facebook
            </button>

            <button className="auth-button" style={{ backgroundColor: '#ea4335' }}>
              Continue with Google
            </button>

            <div className="auth-footer">
              Don&apos;t have an account? <Link href="/register">Sign up here</Link>
            </div>
          </div>
        </div>
      </section>
    </main>
  );
}
