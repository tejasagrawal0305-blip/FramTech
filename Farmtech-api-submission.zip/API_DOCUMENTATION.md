# FarmTech API

Base URL: `http://localhost:3000/api`

## Authentication

Register or log in to receive a bearer token. Send it on protected requests as `Authorization: Bearer <token>`. Passwords are hashed with Node.js `scrypt`; tokens are random server-side sessions that expire after seven days.

## Response format and errors

Successful collection responses use `{ "data": [], "count": 0 }`. Errors use `{ "error": { "message": "..." } }`. Common status codes: `200` success, `201` created, `400` validation error, `401` missing or invalid token, `404` missing resource, and `409` conflict.

## Endpoints

### `GET /health`

Public service check. Returns `status`, `service`, and `timestamp`.

### `POST /auth/register`

Public JSON body: `firstName`, `lastName`, `email`, `phone`, and `password` (minimum 8 characters). Returns `201` with `{ user, token }`.

### `POST /auth/login`

Public JSON body: `email` and `password`. Returns `{ user, token }`; invalid credentials return `401`.

### `GET /equipment`

Public. Optional query parameters: `search`, `location`, and `availability` (`available` or `unavailable`). Returns matching equipment.

### `GET /equipment/:id`

Public. Returns one equipment item or `404`.

### `POST /equipment`

Authenticated. JSON body: `name`, `type`, `location`, and positive numeric `pricePerDay`; optional `availability` and `image`. Returns the created item with `201`.

### `PATCH /equipment/:id`

Authenticated. Updates `name`, `type`, `location`, `pricePerDay`, `availability`, or `image`.

### `DELETE /equipment/:id`

Authenticated. Deletes an equipment item.

### `GET /rentals`

Authenticated. Returns the current user’s rentals.

### `POST /rentals`

Authenticated JSON body: `equipmentId`, `startDate`, and `endDate` in `YYYY-MM-DD` format. The API rejects unavailable equipment, reversed dates, and overlapping pending, confirmed, or active bookings. The response includes calculated `days` and `total` and returns `201`.

### `GET /rentals/:id`

Authenticated. Returns a rental owned by the current user.

### `PATCH /rentals/:id`

Authenticated. JSON body must set `status` to `pending` or `cancelled`.

### `DELETE /rentals/:id`

Authenticated. Deletes a rental owned by the current user.

## Data store

The API creates `data/farmtech.json` on first request and seeds six equipment records. Set `FARMTECH_DB_FILE` to use a different path. The local database is ignored by Git.
