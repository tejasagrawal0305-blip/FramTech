import crypto from 'node:crypto';
import { findOne, insert, list } from '../../../lib/db.js';
import { error, json, requestBody, requireUser } from '../../../lib/http.js';
import { requiredStrings } from '../../../lib/validation.js';

export const runtime = 'nodejs';

export function GET(request) {
  const { searchParams } = new URL(request.url);
  const search = (searchParams.get('search') || '').toLowerCase();
  const location = (searchParams.get('location') || '').toLowerCase();
  const availability = searchParams.get('availability');
  const equipment = list('equipment', (item) =>
    (!search || `${item.name} ${item.type}`.toLowerCase().includes(search)) &&
    (!location || item.location.toLowerCase().includes(location)) &&
    (!availability || item.availability === availability),
  );
  return json({ data: equipment, count: equipment.length });
}

export async function POST(request) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  const body = await requestBody(request);
  if (!body) return error('Request body must be valid JSON');
  const missing = requiredStrings(body, ['name', 'type', 'location']);
  if (missing) return error(missing);
  if (typeof body.pricePerDay !== 'number' || body.pricePerDay <= 0) return error('pricePerDay must be a positive number');
  const equipment = insert('equipment', {
    id: crypto.randomUUID(), name: body.name.trim(), type: body.type.trim(), location: body.location.trim(),
    pricePerDay: body.pricePerDay, rating: 0, availability: body.availability === 'unavailable' ? 'unavailable' : 'available',
    image: body.image || '🚜', owner: `${user.firstName} ${user.lastName}`,
    createdBy: user.id, createdAt: new Date().toISOString(),
  });
  return json(equipment, 201);
}