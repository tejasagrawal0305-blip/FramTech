import crypto from 'node:crypto';
import { findOne, insert, list } from '../../../lib/db.js';
import { error, json, requestBody, requireUser } from '../../../lib/http.js';
import { validDate } from '../../../lib/validation.js';

export const runtime = 'nodejs';

export function GET(request) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  return json({ data: list('rentals', (rental) => rental.userId === user.id) });
}

export async function POST(request) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  const body = await requestBody(request);
  if (!body || typeof body.equipmentId !== 'string' || !validDate(body.startDate) || !validDate(body.endDate)) return error('equipmentId, startDate, and endDate are required and dates must use YYYY-MM-DD');
  if (body.endDate < body.startDate) return error('endDate must be on or after startDate');
  const equipment = findOne('equipment', (item) => item.id === body.equipmentId);
  if (!equipment) return error('Equipment not found', 404);
  if (equipment.availability !== 'available') return error('Equipment is unavailable', 409);
  const overlaps = list('rentals', (rental) => rental.equipmentId === equipment.id && ['pending', 'confirmed', 'active'].includes(rental.status) && rental.startDate <= body.endDate && rental.endDate >= body.startDate);
  if (overlaps.length) return error('Equipment is already booked for these dates', 409);
  const days = Math.round((Date.parse(`${body.endDate}T00:00:00Z`) - Date.parse(`${body.startDate}T00:00:00Z`)) / 86400000) + 1;
  const rental = insert('rentals', { id: crypto.randomUUID(), userId: user.id, equipmentId: equipment.id, equipmentName: equipment.name, startDate: body.startDate, endDate: body.endDate, days, total: days * equipment.pricePerDay, status: 'pending', createdAt: new Date().toISOString() });
  return json(rental, 201);
}