import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import test from 'node:test';

const databaseFile = path.join(os.tmpdir(), `farmtech-api-${process.pid}.json`);
process.env.FARMTECH_DB_FILE = databaseFile;

const { GET: health } = await import('../app/api/health/route.js');
const { POST: register } = await import('../app/api/auth/register/route.js');
const { POST: login } = await import('../app/api/auth/login/route.js');
const equipmentRoutes = await import('../app/api/equipment/route.js');
const equipmentByIdRoutes = await import('../app/api/equipment/[id]/route.js');
const rentalRoutes = await import('../app/api/rentals/route.js');

function request(method, url, body, token) {
  return new Request(`http://localhost${url}`, {
    method,
    headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
    body: body ? JSON.stringify(body) : undefined,
  });
}

const body = (response) => response.json();
test.after(() => fs.rmSync(databaseFile, { force: true }));

test('health endpoint reports service status', async () => {
  const response = health();
  assert.equal(response.status, 200);
  assert.equal((await body(response)).status, 'ok');
});

test('register and login issue tokens without exposing password hashes', async () => {
  const registration = await register(request('POST', '/api/auth/register', { firstName: 'Asha', lastName: 'Patel', email: 'asha@example.com', phone: '+91 9876543210', password: 'secure-pass-123' }));
  const registered = await body(registration);
  assert.equal(registration.status, 201);
  assert.ok(registered.token);
  assert.equal(registered.user.passwordHash, undefined);
  const duplicate = await register(request('POST', '/api/auth/register', { firstName: 'Asha', lastName: 'Patel', email: 'ASHA@example.com', phone: '1', password: 'secure-pass-123' }));
  assert.equal(duplicate.status, 409);
  const loginResponse = await login(request('POST', '/api/auth/login', { email: 'asha@example.com', password: 'secure-pass-123' }));
  assert.equal(loginResponse.status, 200);
  assert.ok((await body(loginResponse)).token);
});

test('equipment supports public reads and authenticated CRUD', async () => {
  const token = (await body(await login(request('POST', '/api/auth/login', { email: 'asha@example.com', password: 'secure-pass-123' })))).token;
  const listResponse = equipmentRoutes.GET(request('GET', '/api/equipment?location=Punjab'));
  const list = await body(listResponse);
  assert.equal(listResponse.status, 200);
  assert.ok(list.count > 0);
  const createdResponse = await equipmentRoutes.POST(request('POST', '/api/equipment', { name: 'Test Plough', type: 'Plow', location: 'Punjab', pricePerDay: 400 }, token));
  const created = await body(createdResponse);
  assert.equal(createdResponse.status, 201);
  const updatedResponse = await equipmentByIdRoutes.PATCH(request('PATCH', `/api/equipment/${created.id}`, { pricePerDay: 450 }, token), { params: Promise.resolve({ id: created.id }) });
  assert.equal(updatedResponse.status, 200);
  const deletedResponse = await equipmentByIdRoutes.DELETE(request('DELETE', `/api/equipment/${created.id}`, null, token), { params: Promise.resolve({ id: created.id }) });
  assert.equal(deletedResponse.status, 200);
});

test('rentals enforce authentication and date conflicts', async () => {
  assert.equal(rentalRoutes.GET(request('GET', '/api/rentals')).status, 401);
  const token = (await body(await login(request('POST', '/api/auth/login', { email: 'asha@example.com', password: 'secure-pass-123' })))).token;
  const equipment = await body(equipmentRoutes.GET(request('GET', '/api/equipment')));
  const equipmentId = equipment.data.find((item) => item.availability === 'available').id;
  const rentalResponse = await rentalRoutes.POST(request('POST', '/api/rentals', { equipmentId, startDate: '2030-01-01', endDate: '2030-01-03' }, token));
  const rental = await body(rentalResponse);
  assert.equal(rentalResponse.status, 201);
  assert.equal(rental.days, 3);
  const conflict = await rentalRoutes.POST(request('POST', '/api/rentals', { equipmentId, startDate: '2030-01-02', endDate: '2030-01-04' }, token));
  assert.equal(conflict.status, 409);
});