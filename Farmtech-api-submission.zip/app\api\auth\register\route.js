import crypto from 'node:crypto';
import { createSession, hashPassword } from '../../../../lib/auth.js';
import { findOne, insert } from '../../../../lib/db.js';
import { error, json, requestBody } from '../../../../lib/http.js';
import { publicUser, requiredStrings } from '../../../../lib/validation.js';

export const runtime = 'nodejs';

export async function POST(request) {
  const body = await requestBody(request);
  if (!body) return error('Request body must be valid JSON');
  const missing = requiredStrings(body, ['firstName', 'lastName', 'email', 'phone', 'password']);
  if (missing) return error(missing);
  if (!/^\S+@\S+\.\S+$/.test(body.email)) return error('email must be valid');
  if (body.password.length < 8) return error('password must be at least 8 characters');
  const email = body.email.trim().toLowerCase();
  if (findOne('users', (user) => user.email === email)) return error('An account with this email already exists', 409);

  const user = insert('users', {
    id: crypto.randomUUID(), firstName: body.firstName.trim(), lastName: body.lastName.trim(),
    email, phone: body.phone.trim(), passwordHash: hashPassword(body.password), role: 'customer',
    createdAt: new Date().toISOString(),
  });
  return json({ user: publicUser(user), token: createSession(user.id) }, 201);
}