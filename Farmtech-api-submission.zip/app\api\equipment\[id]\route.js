import { findOne, remove, update } from '../../../../lib/db.js';
import { error, json, requestBody, requireUser } from '../../../../lib/http.js';

export const runtime = 'nodejs';

export async function GET(_request, { params }) {
  const { id } = await params;
  const equipment = findOne('equipment', (item) => item.id === id);
  return equipment ? json(equipment) : error('Equipment not found', 404);
}

export async function PATCH(request, { params }) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  const id = (await params).id;
  if (!findOne('equipment', (item) => item.id === id)) return error('Equipment not found', 404);
  const body = await requestBody(request);
  if (!body || Object.keys(body).some((field) => !['name', 'type', 'location', 'pricePerDay', 'availability', 'image'].includes(field))) return error('Invalid equipment fields');
  if (body.pricePerDay !== undefined && (typeof body.pricePerDay !== 'number' || body.pricePerDay <= 0)) return error('pricePerDay must be a positive number');
  const equipment = update('equipment', (item) => item.id === id, body);
  return json(equipment);
}

export async function DELETE(request, { params }) {
  const user = requireUser(request);
  if (user instanceof Response) return user;
  const { id } = await params;
  const deleted = remove('equipment', (item) => item.id === id);
  return deleted ? json({ message: 'Equipment deleted' }) : error('Equipment not found', 404);
}