# FarmTech Deployment Guide

## 1. Deployment target

FarmTech is prepared for deployment on [Render](https://render.com) as a Node web service. Render is selected because the current backend uses a local JSON document database and therefore needs a persistent disk. A stateless serverless deployment must not be used with the current store because instance-local files can disappear between requests.

For production scale, replace the JSON store with PostgreSQL, MongoDB, or another managed database before choosing a stateless platform.

## 2. Production readiness checklist

- Node.js 20 or newer
- `npm ci` succeeds from the repository root
- `npm run build` completes successfully
- `npm test`, `npm run test:frontend`, and `npm run lint` pass
- `FARMTECH_DB_FILE` points to persistent storage
- HTTPS is enabled by the hosting platform
- Real payment-card values are not sent to the FarmTech API; checkout payment processing is a presentation placeholder
- Database backups and access controls are configured for the persistent disk
- A monitoring and rollback owner is identified

## 3. Deploy with Render Blueprint

1. Push the repository to GitHub, GitLab, or Bitbucket.
2. Sign in to Render and choose **New > Blueprint**.
3. Select the repository containing `render.yaml`.
4. Review the service name, `starter` plan, build command, and start command.
5. Confirm the persistent disk is mounted at `/var/data`.
6. Create the Blueprint and wait for the build to finish.
7. Render provides a public HTTPS URL such as `https://farmtech.onrender.com`.
8. Open the URL and confirm the home page, equipment page, login page, and registration page load.

The repository also contains `.env.example` for local production-like configuration. Do not commit real secrets or user database files. The current API does not require a secret key because sessions are stored in the database, but a production migration should introduce a managed session/auth provider and platform secret variables.

## 4. Manual Render setup

If a Blueprint is not used, create a **Web Service** with:

| Setting | Value |
| --- | --- |
| Environment | Node |
| Build command | `npm ci && npm run build` |
| Start command | `npm run start` |
| Node version | 20 or newer |
| `NODE_ENV` | `production` |
| `FARMTECH_DB_FILE` | `/var/data/farmtech.json` |
| Persistent disk mount | `/var/data` |

## 5. Post-deployment user acceptance test

Run these checks against the public URL:

1. `GET /api/health` returns HTTP `200` and `{ "status": "ok" }`.
2. The equipment page displays seeded equipment from `GET /api/equipment`.
3. Register a test account using a non-sensitive test email.
4. Log in and verify the browser navigates to My Rentals.
5. Create a booking from Checkout using valid future dates.
6. Refresh My Rentals and verify the booking remains present, proving disk persistence.
7. Attempt an overlapping booking and verify the API returns HTTP `409`.
8. Refresh the deployed app from a new browser session and verify public routes remain available.
9. Delete the test rental and confirm the API returns HTTP `200`.

Record the deployment URL, deployment commit, test date, browser, and pass/fail result in the release checklist.

## 6. Troubleshooting

### Build fails during `npm ci`

Confirm the service uses Node 20 or newer, the lockfile is committed, and the build is running from the repository root. Run `npm ci` locally to reproduce the dependency error.

### Application starts but API requests return 500

Check service logs and verify that the disk mount exists and `FARMTECH_DB_FILE` points inside it. The process must have write permission to the directory. Delete only a corrupted test database after taking a backup; a missing file is recreated and seeded automatically.

### Data disappears after redeploy

The service is running without a persistent disk or the environment variable points to an ephemeral path. Attach the disk at `/var/data` and set `FARMTECH_DB_FILE=/var/data/farmtech.json`.

### Frontend shows authentication errors

Clear the browser's `farmtech_token` localStorage value, log in again, and check that the request includes `Authorization: Bearer <token>`. Expired sessions last seven days and require a new login.

### Rental booking returns `409`

The equipment may be unavailable or already booked for an overlapping pending, confirmed, or active date range. Choose another item or a non-overlapping range.

### Health check fails after deployment

Inspect the start command and service logs. Confirm the platform assigned `PORT` is not overridden by a hard-coded server setting. Run `npm run start` locally after `npm run build` to reproduce startup issues.

## 7. Rollback

Render retains previous deploys. If a release fails acceptance testing, redeploy the previous known-good commit, preserve the persistent disk, and record the incident. Do not replace or reinitialize the database during an application rollback. Restore a database backup only after confirming corruption and documenting the recovery point.