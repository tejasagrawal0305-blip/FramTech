from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.shared import Inches, Pt, RGBColor

report = Document()
styles = report.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal'].font.size = Pt(10.5)
styles['Normal'].font.color.rgb = RGBColor(33, 53, 43)
section = report.sections[0]
section.top_margin = Inches(0.7)
section.bottom_margin = Inches(0.7)
section.left_margin = Inches(0.75)
section.right_margin = Inches(0.75)

# Cover
p = report.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('FARMTECH')
r.bold = True
r.font.size = Pt(30)
r.font.color.rgb = RGBColor(19, 92, 61)
p = report.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Testing, Debugging, and Optimization Report')
r.bold = True
r.font.size = Pt(17)
r.font.color.rgb = RGBColor(39, 174, 96)
p = report.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('Quality assurance and performance evaluation | September 2026').italic = True
report.add_paragraph('')
p = report.add_paragraph()
p.alignment = WD_ALIGN_PARAGRAPH.CENTER
p.add_run('Full-stack agricultural equipment rental application').font.size = Pt(13)

report.add_heading('1. Executive Summary', level=1)
report.add_paragraph(
    'This report describes the testing, debugging, and optimization work completed for FarmTech, a full-stack agricultural equipment rental application. '
    'The system consists of a Next.js frontend, RESTful backend Route Handlers, and a local JSON document database. The quality process was designed '
    'to verify both isolated logic and complete user-facing behavior. Unit tests cover validation, password hashing, safe user serialization, and data '
    'normalization. Backend integration tests exercise authentication, equipment CRUD operations, authorization, rental calculations, availability, and '
    'date-conflict rules. Frontend smoke tests request each primary application route to confirm that the built interface is reachable. The project also '
    'includes a repeatable performance benchmark for equipment reads, a debugging log, and documented optimization decisions. During this work, testing '
    'identified an important date-validation defect: JavaScript normalizes invalid dates such as February 30 instead of rejecting them. The validator was '
    'repaired to compare parsed UTC components with the original input. Other findings included asynchronous dynamic route parameters, JSX lint errors, '
    'and the need to replace mock frontend alerts with observable API states. After repair, eight unit and API tests, six frontend smoke tests, lint, and '
    'the production build passed. The result is a more reliable application with repeatable verification commands and clear evidence for future maintenance.'
)

report.add_heading('2. Testing Objectives', level=1)
for item in [
    'Verify pure business and security helpers independently from HTTP concerns.',
    'Confirm that backend endpoints work together with authentication and persistent data.',
    'Check that protected resources reject missing credentials and enforce record ownership.',
    'Validate the frontend route surface and its ability to render under the development server.',
    'Detect invalid inputs, duplicate requests, unavailable equipment, and overlapping bookings.',
    'Measure a repeatable local read operation to establish a performance regression baseline.',
    'Document defects, root causes, corrective actions, and remaining production risks.',
]:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('3. Test Strategy', level=1)
report.add_paragraph('The project uses the Node.js built-in test runner. This keeps the suite lightweight and avoids an additional framework configuration while still providing assertions, test isolation, test reporting, and lifecycle hooks. Tests are separated by scope so failures identify the affected layer quickly.')
strategy = report.add_table(rows=1, cols=4)
strategy.alignment = WD_TABLE_ALIGNMENT.CENTER
strategy.style = 'Table Grid'
for cell, text in zip(strategy.rows[0].cells, ['Test level', 'File', 'Scope', 'Execution']):
    cell.text = text
for row in [
    ('Unit', 'tests/unit.test.mjs', 'Pure validation, security, and mapping helpers', 'npm run test:unit'),
    ('Backend integration', 'tests/api.test.mjs', 'Route handlers, auth, CRUD, rentals, and database', 'npm run test:api'),
    ('Frontend smoke', 'tests/frontend-smoke.test.mjs', 'Primary rendered page routes', 'npm run test:frontend'),
    ('Performance', 'tools/performance-benchmark.mjs', 'Repeated equipment collection reads', 'npm run perf'),
]:
    cells = strategy.add_row().cells
    for cell, text in zip(cells, row):
        cell.text = text

report.add_heading('4. Unit Test Cases', level=1)
report.add_paragraph('Unit tests target deterministic functions with small inputs and explicit expected outcomes. These tests run without a web server and are fast enough to execute after every code change.')
unit = report.add_table(rows=1, cols=4)
unit.style = 'Table Grid'
for cell, text in zip(unit.rows[0].cells, ['ID', 'Scenario', 'Expected result', 'Status']):
    cell.text = text
for row in [
    ('UT-01', 'Required fields contain blanks or are missing', 'Returns the names of invalid fields', 'Passed'),
    ('UT-02', 'Valid ISO date is supplied', 'Returns true for a real calendar date', 'Passed'),
    ('UT-03', 'Malformed date or February 30 is supplied', 'Returns false without JavaScript date rollover', 'Passed'),
    ('UT-04', 'Correct password is checked against scrypt hash', 'Returns true; plaintext is not stored', 'Passed'),
    ('UT-05', 'Incorrect password is checked', 'Returns false', 'Passed'),
    ('UT-06', 'Public user response is created', 'Removes passwordHash', 'Passed'),
    ('UT-07', 'API equipment item is mapped to card fields', 'Creates price and display availability fields', 'Passed'),
]:
    cells = unit.add_row().cells
    for cell, text in zip(cells, row):
        cell.text = text

report.add_heading('5. Backend Integration Test Cases', level=1)
report.add_paragraph('Backend tests import the Route Handler functions directly and send Request objects with realistic headers and JSON bodies. Each run uses a temporary database path through FARMTECH_DB_FILE, preventing test data from affecting local development records.')
integration = report.add_table(rows=1, cols=4)
integration.style = 'Table Grid'
for cell, text in zip(integration.rows[0].cells, ['ID', 'Scenario', 'Expected result', 'Status']):
    cell.text = text
for row in [
    ('IT-01', 'GET /health', 'Returns 200 and status ok', 'Passed'),
    ('IT-02', 'Register a new user', 'Returns 201 with user and token', 'Passed'),
    ('IT-03', 'Register duplicate email', 'Returns 409 and does not create a second user', 'Passed'),
    ('IT-04', 'Login with valid credentials', 'Returns 200 and bearer token', 'Passed'),
    ('IT-05', 'Public equipment filter by location', 'Returns matching collection and count', 'Passed'),
    ('IT-06', 'Create, update, and delete equipment', 'Authenticated CRUD operations return expected statuses', 'Passed'),
    ('IT-07', 'List rentals without token', 'Returns 401', 'Passed'),
    ('IT-08', 'Create valid rental', 'Returns 201 with calculated days and total', 'Passed'),
    ('IT-09', 'Create overlapping rental', 'Returns 409 conflict', 'Passed'),
    ('IT-10', 'Create rental for unavailable equipment', 'Returns 409 conflict', 'Covered by route rule'),
]:
    cells = integration.add_row().cells
    for cell, text in zip(cells, row):
        cell.text = text

report.add_heading('6. Frontend Smoke Testing', level=1)
report.add_paragraph('The smoke suite runs against the local Next.js development server at http://localhost:3000. It fetches each important page, checks HTTP 200, and verifies that the FarmTech application shell is present in the response. This confirms route registration, server rendering, and basic page availability without coupling the test to fragile CSS selectors.')
for route in ['/', '/equipment', '/login', '/register', '/my-rentals', '/checkout']:
    report.add_paragraph(f'{route} - HTTP 200 and FarmTech shell detected', style='List Bullet')
report.add_paragraph('Result: 6 frontend smoke tests passed.')

report.add_heading('7. Debugging Process and Findings', level=1)
report.add_paragraph('Debugging followed a reproduce, isolate, identify, repair, and rerun cycle. First, focused lint and test commands were used to keep failures close to the changed file. Then route behavior and helper behavior were separated so a failing assertion could identify whether the problem was caused by input validation, persistence, authentication, or presentation mapping.')
debug = report.add_table(rows=1, cols=4)
debug.style = 'Table Grid'
for cell, text in zip(debug.rows[0].cells, ['Finding', 'Root cause', 'Fix', 'Verification']):
    cell.text = text
for row in [
    ('Invalid February 30 accepted', 'Date.parse normalizes calendar overflow', 'Compare UTC year, month, and day after parsing', 'Unit test now passes'),
    ('Dynamic route parser error', 'await params was used inside a non-async predicate', 'Await route params before database queries', 'Focused ESLint passes'),
    ('Mock login and checkout', 'UI used alerts instead of API calls', 'Added shared fetch client and async states', 'Frontend smoke/build pass'),
    ('API/UI field mismatch', 'UI expected price and title-case availability', 'Added equipmentForCard normalizer and card fallback', 'Unit test passes'),
    ('JSX lint errors', 'Unescaped quotes and apostrophes', 'Used JSX entities in touched pages', 'Full lint passes'),
    ('Native SQLite installation failure', 'No compatible binary/toolchain in environment', 'Used dependency-free atomic JSON store', 'Install and tests remain runnable'),
]:
    cells = debug.add_row().cells
    for cell, text in zip(cells, row):
        cell.text = text

report.add_heading('8. Performance and Optimization', level=1)
report.add_paragraph('The performance benchmark executes 100 equipment collection reads against the local document store and prints total and average duration. The recorded baseline for this run was 86.8 ms total and 0.868 ms average per read. This is a local regression signal rather than a production load test; a deployed system should be measured with concurrent traffic and a managed database.')
for item in [
    'A shared API client centralizes fetch setup, JSON parsing, bearer headers, and error extraction.',
    'Equipment filtering runs against one loaded collection, avoiding a network request for each filter change.',
    'Loading and disabled-submit states prevent duplicate authentication and booking requests.',
    'Tests use an isolated temporary database, improving repeatability and preventing data contamination.',
    'Atomic temporary-file replacement reduces the chance of a partially written JSON database.',
    'Same-origin relative API paths avoid a second local server and CORS overhead.',
]:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('9. Final Results', level=1)
results = report.add_table(rows=1, cols=3)
results.style = 'Table Grid'
for cell, text in zip(results.rows[0].cells, ['Validation', 'Result', 'Evidence']):
    cell.text = text
for row in [
    ('Unit and API tests', '8 passed, 0 failed', 'npm test'),
    ('Frontend smoke tests', '6 passed, 0 failed', 'npm run test:frontend'),
    ('Lint', 'Passed with 0 errors and 0 warnings', 'npm run lint'),
    ('Production build', 'Completed successfully', 'npm run build'),
    ('Performance benchmark', '86.8 ms total; 0.868 ms average', 'npm run perf'),
]:
    cells = results.add_row().cells
    for cell, text in zip(cells, row):
        cell.text = text

report.add_heading('10. Limitations and Future Improvements', level=1)
report.add_paragraph('The current quality process is strong for local assessment but has boundaries. The frontend smoke tests validate availability rather than visual regressions or real browser interactions. The JSON store is suitable for a single-process demonstration but should be replaced with a managed relational or document database for concurrent production traffic. Database-level transactions are needed to prevent two simultaneous bookings from passing the overlap check at the same time. Future work should add Playwright interaction tests, coverage thresholds, CI execution, rate limiting, secure httpOnly cookies, role-based equipment authorization, structured logs, monitoring, and load testing. The checkout interface also needs a compliant payment provider before accepting real payment information.')

report.add_heading('11. How to Reproduce', level=1)
report.add_paragraph('From the project root, run the following commands:')
for command in ['npm install', 'npm run test:unit', 'npm run test:api', 'npm run dev  (in a separate terminal)', 'npm run test:frontend', 'npm run lint', 'npm run build', 'npm run perf']:
    p = report.add_paragraph(style='List Bullet')
    p.add_run(command).font.name = 'Consolas'
report.add_paragraph('Supporting files are TESTING_AND_DEBUGGING.md, TEST_ERROR_LOG.md, TEST_RUN_RESULTS.log, tests/, and tools/performance-benchmark.mjs. The main project README includes the same strategy and setup guidance.')

report.add_heading('12. Submission Contents', level=1)
for item in [
    'Complete frontend and backend source code',
    'Unit, backend integration, and frontend smoke test scripts',
    'Performance benchmark script',
    'Testing and debugging report',
    'Error log and recorded test results',
    'README and API documentation',
    'Screenshots, PDF documentation, and local demonstration walkthrough',
]:
    report.add_paragraph(item, style='List Bullet')

report.save('FarmTech-Testing-Debugging-Optimization-Report.docx')
