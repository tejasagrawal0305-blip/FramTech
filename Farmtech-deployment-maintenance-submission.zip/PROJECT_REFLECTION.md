# FarmTech Project Reflection

## What went well

The project benefited from keeping the frontend and backend in one Next.js application. Same-origin relative API requests made local integration straightforward and avoided a separate CORS configuration. The shared API client created a clear boundary between presentation and transport concerns: pages manage user-facing state, while the client adds headers, parses errors, and normalizes API fields. The automated test suite also improved confidence during integration. Unit tests exposed a subtle calendar-date bug, while API integration tests verified authentication, CRUD behavior, ownership, availability, and overlapping bookings. The production build and frontend smoke tests provided a second view of correctness beyond isolated function assertions.

The codebase also became more maintainable because mock alerts were replaced with explicit loading, success, and error states. The README, API documentation, testing report, deployment guide, maintenance plan, and this reflection make the decisions reproducible for another developer.

## Challenges and learning

The main challenge was reconciling a frontend that began with hard-coded demonstration data with a backend that used a stronger data contract. Price naming and availability casing were different, and rental records did not contain every presentation field. The solution was to adapt data at the boundary instead of weakening the server model. This reinforced the value of explicit contracts and small mapping functions.

A second challenge was choosing persistence appropriate to the environment. A native SQLite package could not be installed in the available Node and Windows toolchain, so a dependency-free atomic JSON store was used for local assessment. That decision improved portability but revealed an important deployment limitation: the service needs persistent storage and is not suitable for a stateless serverless deployment without a database migration.

Debugging also showed that seemingly valid JavaScript date parsing can silently normalize invalid calendar values. The repaired validator now compares parsed UTC components with the original input. This was a useful reminder that validation should be tested with boundary and adversarial values, not only happy paths.

## Improvements for future projects

I would define the API schema before building the UI, use a managed database earlier, and add browser-level interaction tests while features are being developed. I would also introduce CI on the first day so every pull request runs tests, lint, and a production build. For production security, I would use httpOnly cookies or a managed identity provider, rate-limit login, add role-based authorization, and integrate a compliant payment provider rather than retaining payment fields in a presentation-only checkout form.

## Final reflection

The project demonstrated that a working interface is only one part of a dependable application. Reliable behavior came from combining clear API contracts, server-side business rules, automated tests, deliberate error handling, performance measurement, deployment constraints, and maintenance procedures. The next stage would be to turn the assessment-ready implementation into an observable production service with transactional persistence, automated delivery, and stronger browser and load testing.