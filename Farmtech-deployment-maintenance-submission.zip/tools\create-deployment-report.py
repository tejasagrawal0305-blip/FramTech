from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.shared import Inches, Pt, RGBColor

report = Document()
styles = report.styles
styles['Normal'].font.name = 'Aptos'
styles['Normal'].font.size = Pt(10.5)
styles['Normal'].font.color.rgb = RGBColor(33, 53, 43)
section = report.sections[0]
section.top_margin = Inches(0.7)
section.bottom_margin = Inches(0.7)
section.left_margin = Inches(0.75)
section.right_margin = Inches(0.75)

p = report.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('FARMTECH'); r.bold = True; r.font.size = Pt(30); r.font.color.rgb = RGBColor(19, 92, 61)
p = report.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
r = p.add_run('Deployment, Maintenance, and Project Reflection Report'); r.bold = True; r.font.size = Pt(17); r.font.color.rgb = RGBColor(39, 174, 96)
p = report.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.add_run('September 2026').italic = True

report.add_heading('1. Executive Summary', level=1)
report.add_paragraph('This report explains how FarmTech is prepared for deployment, how the running service should be maintained, and what was learned during development. FarmTech is a Next.js full-stack agricultural equipment rental application with browser pages, REST API Route Handlers, authentication, equipment management, rental booking, validation, tests, and a local JSON document store. The selected deployment target is Render because the current store requires persistent disk storage. A Render Blueprint is included so another developer can deploy the application reproducibly with a Node web service, production build command, start command, environment variables, and a mounted data disk. The deployment guide includes a production readiness checklist, post-deployment user acceptance test, common troubleshooting procedures, rollback guidance, and an explanation of why the current implementation should not be placed on a stateless serverless platform without first migrating the database. The maintenance plan defines health checks, log review, error reporting, encrypted backups, restore drills, dependency updates, release control, incident response, and a roadmap toward managed transactional storage. The reflection evaluates successful decisions, integration and environment challenges, debugging lessons, and improvements for future work. No public deployment was created in this workspace because hosting credentials were not available; this is stated clearly and the deployment process is fully documented for execution with the owner\'s hosting account.')

report.add_heading('2. Deployment Architecture', level=1)
report.add_paragraph('The deployed application runs as one Node-based Next.js web service. The browser and API share one HTTPS origin, allowing relative /api requests without CORS configuration. Render builds the application with npm ci and npm run build, then starts it with npm run start. The persistent disk is mounted at /var/data and FARMTECH_DB_FILE points to /var/data/farmtech.json. The API creates and seeds the file only when it does not exist. This preserves records through normal redeploys, although a managed database is recommended for production scale.')
architecture = report.add_table(rows=1, cols=3); architecture.style = 'Table Grid'; architecture.alignment = WD_TABLE_ALIGNMENT.CENTER
for cell, text in zip(architecture.rows[0].cells, ['Component', 'Production role', 'Configuration']): cell.text = text
for row in [('Render web service', 'Runs Next.js frontend and API', 'Node runtime; npm ci, build, start'), ('Persistent disk', 'Stores users, sessions, equipment, rentals', 'Mount /var/data'), ('Environment variables', 'Select production mode and database path', 'NODE_ENV=production; FARMTECH_DB_FILE=/var/data/farmtech.json'), ('HTTPS platform URL', 'Public browser and API access', 'Render-provided HTTPS URL')]:
    cells = architecture.add_row().cells
    for cell, text in zip(cells, row): cell.text = text

report.add_heading('3. Deployment Procedure', level=1)
for item in ['Push the repository to GitHub, GitLab, or Bitbucket.', 'Create a Render Blueprint and select the repository containing render.yaml.', 'Review the Node runtime, starter plan, build command, start command, environment variables, and persistent disk.', 'Create the service and wait for the production build to complete.', 'Open the assigned HTTPS URL and record the commit, deploy time, and URL.', 'Run the post-deployment acceptance checklist before announcing the release.']:
    report.add_paragraph(item, style='List Number')
report.add_paragraph('Manual Web Service setup is also documented for cases where a Blueprint is not used. The deployment must use a persistent disk with the current JSON store. The public deployment was not executed from this workspace because no hosting account or deployment credentials were provided.')

report.add_heading('4. User Acceptance Testing', level=1)
report.add_paragraph('The deployment guide defines acceptance checks that verify both public and protected behavior. Health must return HTTP 200. Equipment must load from the API. A test account must register and log in. A future booking must persist after refresh, and an overlapping booking must return HTTP 409. The test rental is then deleted. The tester should record the public URL, commit, date, browser, and each pass or fail result. Persistence after a refresh is particularly important because it proves the mounted disk is being used rather than ephemeral instance storage.')
acceptance = report.add_table(rows=1, cols=3); acceptance.style = 'Table Grid'
for cell, text in zip(acceptance.rows[0].cells, ['Check', 'Expected result', 'Evidence']): cell.text = text
for row in [('Health endpoint', 'HTTP 200 and status ok', 'Response capture'), ('Equipment browsing', 'Seeded records render', 'Browser screenshot'), ('Registration/login', 'Token issued and protected route opens', 'Test account result'), ('Booking persistence', 'Rental remains after refresh', 'My Rentals result'), ('Conflict handling', 'Overlapping booking returns 409', 'API response'), ('Cleanup', 'Test rental deletes successfully', 'HTTP 200 response')]:
    cells = acceptance.add_row().cells
    for cell, text in zip(cells, row): cell.text = text

report.add_heading('5. Maintenance Strategy', level=1)
report.add_paragraph('Maintenance is organized around observability, data protection, controlled releases, and recovery. Daily checks should inspect the health endpoint, service logs, disk usage, and recent errors. Weekly review should look for authentication spikes, repeated 500 responses, unusual booking conflicts, and user-reported failures. Database backups should be copied to encrypted external storage at least daily and verified through periodic restore drills. Monthly work includes dependency updates, environment and access review, and capacity review. Quarterly work includes a recovery exercise and rollback rehearsal.')
for item in ['Use structured logs with request ID, route, status, duration, and sanitized user identifier.', 'Never log passwords, bearer tokens, authorization headers, or payment-card information.', 'Configure a managed error tracker with personally identifiable information scrubbing.', 'Back up the JSON file before releases and retain an incident copy before restoration.', 'Use branches and pull requests; require tests, lint, and build checks before deployment.', 'Keep the previous known-good commit available for rollback and do not reinitialize the database during an application rollback.']:
    report.add_paragraph(item, style='List Bullet')

report.add_heading('6. Troubleshooting and Recovery', level=1)
report.add_paragraph('The deployment guide covers dependency, startup, persistence, authentication, booking conflict, and health-check failures. Build errors should be reproduced with npm ci and npm run build using Node 20 or newer. API 500 responses should be investigated through service logs and the database path and write permissions. Disappearing data indicates a missing persistent disk or an incorrect FARMTECH_DB_FILE value. Authentication failures can be resolved by removing the farmtech_token browser value and logging in again. A 409 booking response is normally a valid business rule, not a server fault. For serious incidents, preserve logs and the current database, stabilize with rollback or maintenance mode, restore only a validated backup, run acceptance checks, and document the recovery point.')

report.add_heading('7. Project Reflection', level=1)
report.add_heading('What went well', level=2)
report.add_paragraph('Keeping the frontend and backend in one Next.js project made the integration simple and eliminated local CORS complexity. The shared API client provided one location for bearer headers, error parsing, and equipment field normalization. Automated tests caught issues that were not obvious from visual inspection, including invalid date rollover and route parameter handling. Replacing mock alerts with loading, success, and failure states made the application more realistic and maintainable.')
report.add_heading('Challenges and lessons', level=2)
report.add_paragraph('The original frontend used hard-coded records and a different naming convention from the API. A small boundary adapter solved the mismatch without weakening the server contract. The native SQLite installation was not compatible with the available Windows toolchain, which led to a portable JSON store and also highlighted the difference between assessment infrastructure and production infrastructure. Date parsing was another lesson: standard parsing can normalize invalid calendar values, so validation must test boundary cases explicitly. Deployment planning exposed that persistence requirements should influence hosting selection from the beginning.')
report.add_heading('Future improvements', level=2)
report.add_paragraph('The next version should migrate to a managed transactional database, add database-level booking constraints, secure httpOnly session cookies, rate limiting, role-based authorization, CI/CD, browser interaction tests, load testing, structured monitoring, and a compliant payment provider. I would also define API schemas before building UI components and include deployment acceptance tests in continuous delivery from the first iteration.')

report.add_heading('8. Deliverables and Reproduction', level=1)
for item in ['DEPLOYMENT_GUIDE.md - Render deployment, acceptance testing, troubleshooting, and rollback.', 'MAINTENANCE_PLAN.md - Operations cadence, logging, backups, updates, and incident response.', 'PROJECT_REFLECTION.md - Detailed reflection and future improvements.', 'render.yaml and .env.example - Deployment and environment configuration.', 'README.md - Local setup and links to all project documentation.', 'FarmTech-Testing-Debugging-Optimization-Report.docx and test artifacts - Quality evidence.']:
    report.add_paragraph(item, style='List Bullet')
report.add_paragraph('Local setup: npm install, npm run dev. Verification: npm test, npm run test:frontend while the server is running, npm run lint, npm run build, and npm run perf.')

report.save('FarmTech-Deployment-Maintenance-Reflection-Report.docx')
