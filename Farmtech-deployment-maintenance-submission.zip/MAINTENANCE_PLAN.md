# FarmTech Maintenance Plan

## Operational cadence

| Frequency | Activity | Owner / evidence |
| --- | --- | --- |
| Every deploy | Run unit, API, frontend smoke, lint, and build checks | CI log and deployment commit |
| Daily | Check health endpoint, service logs, disk usage, and recent errors | Operations checklist |
| Weekly | Review authentication failures, booking conflicts, and user-reported issues | Support issue summary |
| Weekly | Copy and verify the JSON database backup | Backup timestamp and restore test |
| Monthly | Update dependencies in a branch and run the full suite | Pull request and test result |
| Monthly | Review access permissions, environment variables, and disk capacity | Security review |
| Quarterly | Perform a restore drill and deployment rollback rehearsal | Recovery record |

## Logging and error reporting

The current application returns consistent JSON error envelopes without exposing stack traces. Hosting logs should be retained for at least 30 days and searched for HTTP 500 responses, failed health checks, authentication spikes, database parse errors, and repeated booking conflicts. A production enhancement should add structured request IDs, route names, status codes, duration, and sanitized user identifiers to server logs.

Never log passwords, bearer tokens, full payment-card data, or the contents of authorization headers. Redact email addresses and phone numbers in shared incident reports. Configure a managed error tracker such as Sentry after deployment, with source maps and personally identifiable information scrubbing enabled.

## Backup and recovery

The JSON file is the system of record for this deployment. Back it up before every release and at least daily. Keep encrypted copies outside the application disk, verify the backup can be parsed, and periodically restore it into a separate staging environment. A restore procedure is:

1. Stop or place the service in maintenance mode.
2. Copy the current database to an incident archive.
3. Validate the selected backup JSON.
4. Restore it as `FARMTECH_DB_FILE` on the persistent disk.
5. Run health, authentication, equipment, and rental acceptance tests.
6. Record the recovery point and reopen the service.

## Updates and change control

All changes should use a branch and pull request. Required checks are unit tests, API integration tests, frontend smoke tests, lint, and production build. Review database compatibility and migration needs before changing record shapes. Deploy one known commit at a time, run the acceptance checklist, monitor logs, and keep the previous commit available for rollback.

Dependency updates should be reviewed for Node compatibility and security advisories. Use `npm audit` as an additional advisory check, but review whether a reported package is actually in the runtime path before prioritizing remediation.

## Incident response

For a production incident, record start time, affected URL/route, symptoms, recent commit, logs, user impact, and actions taken. Stabilize first by rolling back or disabling the affected workflow. Preserve logs and the database before repair. After recovery, write a short post-incident review with root cause, detection gap, corrective action, and a test that prevents recurrence.

## Production roadmap

Before serving significant traffic, migrate from the local JSON file to a managed transactional database, add database-level booking constraints, use secure httpOnly cookies or a managed identity provider, add rate limiting, add uptime/error monitoring, implement CI/CD, and add browser interaction tests and load tests.