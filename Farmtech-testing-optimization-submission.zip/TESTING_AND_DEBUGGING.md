# Testing, Debugging, and Optimization Report

## Strategy

FarmTech uses the Node.js built-in test runner so the test suite does not require a separate test framework or browser driver. Tests are split by responsibility:

- `tests/unit.test.mjs` checks pure validation, password hashing, safe user serialization, and frontend equipment field normalization.
- `tests/api.test.mjs` runs route-handler integration tests against an isolated temporary database. It covers health, registration, duplicate-account protection, login, equipment CRUD, authentication enforcement, rental creation, calculated duration, and booking conflicts.
- `tests/frontend-smoke.test.mjs` checks that every primary browser route responds with HTTP 200 and contains the FarmTech application shell. Run it while `npm run dev` is active.

## Commands

```bash
npm install
npm run test:unit
npm run test:api
npm run test:all
npm run lint
npm run build
npm run perf
```

`npm test` runs the unit and API suites. `npm run test:frontend` requires the local development server at `http://localhost:3000`.

## Debugging process

The first integration review found that the frontend still used mock alerts and hard-coded values. The API contract also returned `pricePerDay` and lowercase availability values while the card expected `price` and title-cased text. The fix was a shared `api-client.js` normalizer and a single request wrapper that centralizes bearer headers and API error parsing.

During route validation, Next.js dynamic route parameters were confirmed to be asynchronous. The initial handlers attempted to use `await params` inside synchronous predicate callbacks, which caused a parser error. The route handlers were corrected to await the parameter object before querying the store. Focused ESLint checks were rerun after that repair.

The original frontend lint run also exposed unescaped apostrophes and quotation marks in existing JSX. Those errors were corrected in the touched pages so the integrated slice has a clean lint result. The production build was then used as a second validation layer to confirm all Route Handlers compile and are discoverable.

## Optimization work

- Relative same-origin API URLs eliminate an extra server and CORS round trip during local use.
- One API client avoids repeated request/header/error parsing code across pages.
- Equipment filtering happens against one loaded collection instead of issuing a request for every filter keystroke.
- Loading and disabled-submit states prevent duplicate booking and authentication requests.
- The database writes through a temporary file and rename, avoiding corrupted partial documents.
- `FARMTECH_DB_FILE` lets tests use isolated files, preventing test data contamination and making runs repeatable.

`tools/performance-benchmark.mjs` measures 100 equipment reads and prints total and average time. The recorded local baseline for this run was **86.8 ms total** and **0.868 ms average per read**. It is a lightweight regression signal for this local document store; production work should replace it with a managed database benchmark under concurrent load.

## Results

The unit suite covers four helper behaviors, the API suite covers four end-to-end route scenarios, and the frontend smoke suite covers six application routes. Final result: **8 unit/API tests passed, 6 frontend smoke tests passed, lint passed, and production build passed**. The known build warning concerns dynamic filesystem tracing from the intentionally configurable local document store, not a functional failure.

## Lessons learned

Keep server response models stable and adapt presentation-specific naming at the boundary. Put authorization and booking conflict decisions on the server even when the client has matching UI checks. Test pure helpers independently, then test route combinations with an isolated store, and finally smoke-test the rendered application so API correctness and browser availability are verified together.