import assert from 'node:assert/strict';
import test from 'node:test';
import { hashPassword, verifyPassword } from '../lib/auth.js';
import { equipmentForCard } from '../app/lib/api-client.js';
import { publicUser, requiredStrings, validDate } from '../lib/validation.js';

test('requiredStrings reports only blank or missing fields', () => {
  assert.equal(requiredStrings({ firstName: 'Asha', email: ' ' }, ['firstName', 'email', 'phone']), 'Required fields: email, phone');
  assert.equal(requiredStrings({ firstName: 'Asha' }, ['firstName']), null);
});

test('validDate accepts calendar dates and rejects malformed dates', () => {
  assert.equal(validDate('2030-01-03'), true);
  assert.equal(validDate('2030-02-30'), false);
  assert.equal(validDate('03/01/2030'), false);
});

test('password hashing verifies the original password only', () => {
  const stored = hashPassword('secure-pass-123');
  assert.equal(verifyPassword('secure-pass-123', stored), true);
  assert.equal(verifyPassword('wrong-password', stored), false);
  assert.notEqual(stored, 'secure-pass-123');
});

test('publicUser strips password hashes and equipment data maps to card fields', () => {
  assert.deepEqual(publicUser({ id: '1', email: 'a@example.com', passwordHash: 'secret' }), { id: '1', email: 'a@example.com' });
  assert.deepEqual(equipmentForCard({ pricePerDay: 800, availability: 'available' }), { pricePerDay: 800, price: 800, availability: 'Available' });
});