import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { performance } from 'node:perf_hooks';

const databaseFile = path.join(os.tmpdir(), `farmtech-perf-${process.pid}.json`);
process.env.FARMTECH_DB_FILE = databaseFile;
const { list } = await import('../lib/db.js');
const iterations = 100;
const started = performance.now();
for (let index = 0; index < iterations; index += 1) list('equipment');
const elapsed = performance.now() - started;
fs.rmSync(databaseFile, { force: true });
console.log(JSON.stringify({ operation: 'list equipment', iterations, totalMs: Number(elapsed.toFixed(2)), averageMs: Number((elapsed / iterations).toFixed(3)) }, null, 2));