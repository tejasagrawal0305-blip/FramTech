# Test and Debug Error Log

This log records the issues encountered during the testing and integration pass.

| Stage | Symptom | Root cause | Resolution | Result |
| --- | --- | --- | --- | --- |
| Dependency setup | `better-sqlite3` failed during `node-gyp rebuild` | Node 20 environment had no compatible prebuilt binary and no Visual C++ toolchain | Replaced the native dependency with the existing dependency-free JSON document store | Resolved |
| Route lint | `Unexpected reserved word 'await'` in dynamic route | `await params` was placed inside a non-async predicate callback | Awaited route params before querying | Resolved |
| Frontend lint | `react/no-unescaped-entities` in checkout/login/rentals | Literal JSX quotes and apostrophes | Escaped characters with JSX entities | Resolved in touched files |
| Full build | Dynamic filesystem tracing warning | Configurable local database path is discovered dynamically | Documented as an expected deployment warning; build still completes | Accepted |

## Evidence commands

```bash
npm run test:unit
npm run test:api
npm run test:frontend
npm run lint
npm run build
npm run perf
```

Expected API/unit result: all tests pass. Frontend smoke tests require `npm run dev` in another terminal.