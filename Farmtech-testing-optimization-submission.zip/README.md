# FarmTech

FarmTech is a full-stack Next.js agricultural equipment rental application with a REST API and a local file-backed JSON document database. The browser UI now communicates with the API for equipment, authentication, rentals, and checkout booking.

## Setup

```bash
npm install
npm run dev
```

Open `http://localhost:3000`. The API is available at `http://localhost:3000/api` and initializes `data/farmtech.json` with demo equipment on first request.

## Frontend-backend integration

- `app/lib/api-client.js` provides one browser-safe `fetch` wrapper, adds the saved bearer token, parses API errors, and normalizes equipment fields for existing cards.
- The equipment page loads live records from `GET /api/equipment`, applies search/category/location/price filters, and shows loading and fallback states.
- Login and registration call the authentication endpoints, save the returned token in `localStorage`, and navigate to the rentals view on success.
- My Rentals calls `GET /api/rentals`, maps API statuses into the existing tabs, and reports authentication or network errors without crashing the page.
- Checkout loads available equipment and submits `POST /api/rentals`; server-side availability and date-conflict errors are shown in the form.

The API and frontend run in the same Next.js process, so browser requests use relative `/api` URLs and require no CORS configuration or second server.

## Integration challenges and solutions

The original UI used hard-coded records with `price` and title-cased availability, while the API uses `pricePerDay` and lowercase status values. The shared client and card normalizer bridge those contracts without changing the API model. The original authentication and checkout screens displayed mock alerts; they now use asynchronous requests, disabled submit states, persisted sessions, and server error messages. Rental records do not contain presentation-only owner/location fields, so the rentals view explicitly maps available API fields and labels unavailable detail as such instead of inventing booking data.

## Demo

`Farmtech-project-report.pdf` contains screenshots of the running home, equipment, login, and rentals pages. `demo-video.html` is a locally playable walkthrough page with the same live application routes; open it while `npm run dev` is running. A binary screen recording cannot be captured reliably by the current VS Code browser integration, so the walkthrough is included as a reproducible local demonstration.

## Verification

```bash
npm test
npm run lint
npm run build
```

Use `FARMTECH_DB_FILE` to point the API at another database path, which is useful for isolated test or deployment environments.

## Testing strategy

- `npm run test:unit` runs pure helper tests for required-field validation, strict calendar dates, password hashing, safe user serialization, and equipment field normalization.
- `npm run test:api` runs route-handler integration tests against an isolated temporary database. It covers health, authentication, duplicate registration, equipment CRUD, authorization, rental totals, availability, and date conflicts.
- `npm run test:frontend` smoke-tests `/`, `/equipment`, `/login`, `/register`, `/my-rentals`, and `/checkout` against the running development server. Start `npm run dev` in another terminal first.
- `npm run perf` performs a repeatable 100-read local benchmark and reports total and average time.

The full testing and debugging record is in [TESTING_AND_DEBUGGING.md](TESTING_AND_DEBUGGING.md), with the issue log in [TEST_ERROR_LOG.md](TEST_ERROR_LOG.md). The current benchmark baseline is recorded there, and the optimization summary covers shared request handling, duplicate-submit prevention, isolated test data, and atomic persistence writes.

## Backend documentation

See [API_DOCUMENTATION.md](API_DOCUMENTATION.md) for endpoint methods, parameters, authentication, validation rules, business rules, and response formats.
