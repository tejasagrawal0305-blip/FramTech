import assert from 'node:assert/strict';
import test from 'node:test';

const routes = ['/', '/equipment', '/login', '/register', '/my-rentals', '/checkout'];

for (const route of routes) {
  test(`frontend route ${route} renders successfully`, async () => {
    const response = await fetch(`http://localhost:3000${route}`);
    const html = await response.text();
    assert.equal(response.status, 200);
    assert.match(html, /FarmTech/);
  });
}